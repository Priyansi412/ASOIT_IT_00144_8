let x=20 ,y=25

var z=x+y
console.log("sum of x+y is:",z);
document.write("sum of x+y is:",z);